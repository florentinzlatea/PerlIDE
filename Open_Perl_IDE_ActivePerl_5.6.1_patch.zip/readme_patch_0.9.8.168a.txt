Open Perl IDE - Patch 0.9.8.168a
Copyright � 2001 J�rgen G�ntherodt, All Rights Reserved
e-mail: jguentherodt@users.sourceforge.net
--------------------------------------------------------------------------------

There is a big problem with the new ActivePerl Release 5.6.1: 
The IDE Debugger does not work !

This patch should help. 
To install it, simply copy the file dbTemplate.txt into your Open Perl IDE directory and restart the IDE.