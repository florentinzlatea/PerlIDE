Open Perl IDE - HelloWorld Tutorial
Copyright � 2001 J�rgen G�ntherodt, All Rights Reserved
e-mail: jguentherodt@users.sourceforge.net
--------------------------------------------------------------------------------

This file is an update of the HelloWorld.pl example script, now containing a simple tutorial. 
Copy the file into your Open Perl IDE directory, open it in the IDE and follow the tutorial instructions.